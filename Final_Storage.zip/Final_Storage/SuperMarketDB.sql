--Create Database SuoerMarket
--GO

Use SuoerMarket
Go

Select * from Customers
CREATE TABLE Branches (
    BranchID INT   IDENTITY(1,1)  PRIMARY KEY,
    Branch CHAR(1),
    City VARCHAR(255)
);
SET IDENTITY_INSERT Branches ON;

SET IDENTITY_INSERT Branches ON;  -- Enable identity insert

INSERT INTO Branches (BranchID, Branch, City)
SELECT 
    BrachID,
    Branch,
    City
FROM 
    dbo.[supermarket_sales];

SET IDENTITY_INSERT Branches OFF; -- Disable id


-- Enable identity insert temporarily
SET IDENTITY_INSERT Branches ON;

-- Insert data into the Branches table
INSERT INTO Branches (BranchID, Branch, City)
SELECT 
    ISNULL((SELECT MAX(BranchID) FROM Branches), 0) + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS BranchID,
    Branch,
    City
FROM 
    dbo.[supermarket_sales] s
WHERE
    -- Exclude records where BranchID already exists in Branches table
    NOT EXISTS (SELECT 1 FROM Branches b WHERE b.BranchID = s.BrachID);

-- Disable identity insert
SET IDENTITY_INSERT Branches OFF;

Select * from Branches


CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerType VARCHAR(50),
    Gender VARCHAR(50),
	Rating INT,
    BranchID INT, -- Changed to INT to match the BranchID datatype in Branches table
    FOREIGN KEY (BranchID) REFERENCES Branches(BranchID)
);


SELECT CustomerID, COUNT(*)
FROM dbo.[supermarket_sales]
GROUP BY CustomerID
HAVING COUNT(*) > 1;



BEGIN TRANSACTION;

-- Insert new records from the supermarket_sales table
INSERT INTO Customers (CustomerID, CustomerType, Gender, Rating, BranchID)
SELECT 
    s.CustomerID,
    s.Customer_type AS CustomerType,
    s.Gender,
    s.Rating,
    s.BrachID AS BranchID
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY (SELECT NULL)) AS RowNumber
    FROM dbo.[supermarket_sales]
) s
WHERE s.RowNumber = 1;

-- Check for existing duplicates in the Customers table
IF EXISTS (
    SELECT 1
    FROM (
        SELECT CustomerID, COUNT(*) AS DuplicateCount
        FROM Customers
        GROUP BY CustomerID
        HAVING COUNT(*) > 1
    ) AS Duplicates
)
BEGIN
    -- Identify and handle duplicates
    ;WITH DuplicatesCTE AS (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY (SELECT NULL)) AS RowNumber
        FROM Customers
    )
    DELETE FROM DuplicatesCTE WHERE RowNumber > 1;
END

COMMIT TRANSACTION;

Select * from Customers


BEGIN TRANSACTION;

-- Insert new records from the supermarket_sales table, ignoring duplicates
INSERT INTO Customers (CustomerID, CustomerType, Gender, Rating, BranchID)
SELECT 
    s.CustomerID,
    s.Customer_type AS CustomerType,
    s.Gender,
    s.Rating,
    s.BrachID AS BranchID
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY (SELECT NULL)) AS RowNumber
    FROM dbo.[supermarket_sales]
) s
WHERE s.RowNumber = 1
AND NOT EXISTS (
    SELECT 1
    FROM Customers c
    WHERE c.CustomerID = s.CustomerID
);

-- Remove duplicates if any exist
;WITH CTE AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY (SELECT NULL)) AS RowNumber
    FROM Customers
)
DELETE FROM CTE WHERE RowNumber > 1;

COMMIT TRANSACTION;






select * from Customers


CREATE SEQUENCE ProductIDSequence
    AS INT
    START WITH 1
    INCREMENT BY 1;

-- Step 2: Add the ProductID column to your source table
ALTER TABLE dbo.[supermarket_sales]
ADD ProductID INT NULL;

UPDATE dbo.[supermarket_sales]
SET ProductID = ABS(CHECKSUM(NEWID())) % 1000;

ALTER TABLE dbo.[supermarket_sales]
ALTER COLUMN ProductID INT NOT NULL;


UPDATE dbo.[supermarket_sales]
SET ProductID = ABS(CHECKSUM(NEWID())) % 1000; -- Adjust the range as needed


CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductLine VARCHAR(255),
    UnitPrice float,
	Quantity INT,
	Total INT,
    BranchID INT,
    FOREIGN KEY (BranchID) REFERENCES Branches(BranchID)
);

	BEGIN TRANSACTION;

-- Delete existing duplicate records
;WITH CTE_DeleteDuplicates AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY ProductID ORDER BY (SELECT NULL)) AS RowNumber
    FROM dbo.[supermarket_sales]
)
DELETE FROM CTE_DeleteDuplicates WHERE RowNumber > 1;

-- Insert new records from the source table
INSERT INTO Products (ProductID, ProductLine, UnitPrice, Quantity, Total, BranchID)
SELECT 
    ProductID,
    ProductLine,
    UnitPrice,
    Quantity,
    Total,
    BrachID
FROM dbo.[supermarket_sales];

COMMIT TRANSACTION;


Select * from Products

-----------------------------------

CREATE TABLE PaymentMethods (
    PaymentMethodID INT PRIMARY KEY,
    Payment VARCHAR(255), -- Assuming Payment is represented as a float
    BranchID INT,
	UnitPrice FLOAT,
    TotalAmount FLOAT,
	InvoiceID VARCHAR(255),
    PaymentDate VARCHAR(255),
    PaymentTime VARCHAR(255),
    FOREIGN KEY (BranchID) REFERENCES Branches(BranchID)
);

INSERT INTO PaymentMethods (PaymentMethodID, Payment, BranchID, UnitPrice, TotalAmount, InvoiceID, PaymentDate, PaymentTime)
SELECT 
   PaymentMethodID, -- Assuming this corresponds to PaymentMethodID
    Payment,
	BrachID,-- Assuming this corresponds to Payment
    UnitPrice,
-- Assuming this corresponds to BranchID
    Total, -- Assuming this corresponds to UnitPrice
    Invoice_ID, -- Assuming this corresponds to TotalAmount
    Date, -- Assuming this corresponds to InvoiceID
    Time -- Assuming this corresponds to PaymentDate
   
FROM 
     dbo.[supermarket_sales];


	 BEGIN TRANSACTION;

WITH CTE AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY PaymentMethodID ORDER BY (SELECT NULL)) AS RowNumber
    FROM dbo.[supermarket_sales]
)
DELETE FROM CTE WHERE RowNumber > 1;

INSERT INTO PaymentMethods (PaymentMethodID, Payment, BranchID, UnitPrice, TotalAmount, InvoiceID, PaymentDate, PaymentTime)
SELECT 
     PaymentMethodID, -- Assuming this corresponds to PaymentMethodID
    Payment,
	BrachID,-- Assuming this corresponds to Payment
    UnitPrice,
-- Assuming this corresponds to BranchID
    Total, -- Assuming this corresponds to UnitPrice
    Invoice_ID, -- Assuming this corresponds to TotalAmount
    Date, -- Assuming this corresponds to InvoiceID
    Time -- Assuming this corresponds to PaymentDate
   
FROM 
   dbo.[supermarket_sales];

COMMIT TRANSACTION;


Select * from PaymentMethods

