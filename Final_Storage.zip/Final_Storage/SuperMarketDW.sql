USE [Sales_DW]
GO

/****** Object:  Table [dbo].[Calendar_Dim]    Script Date: 4/9/2024 11:04:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE Fact_Sales (
    SaleKey INT NOT NULL IDENTITY,
    OrderKey INT,
    ProductKey INT,
    AisleKey INT,
    DepartmentKey INT,
    Quantity INT,
    SaleAmount DECIMAL(10,2),
    SaleDate DATE,
    PRIMARY KEY (SaleKey),
    FOREIGN KEY (OrderKey) REFERENCES Order_Dim(OrderKey),
    FOREIGN KEY (ProductKey) REFERENCES Product_Dim(ProductKey),
    FOREIGN KEY (AisleKey) REFERENCES Aisles_Dim(AislesKey),
    FOREIGN KEY (DepartmentKey) REFERENCES Department_Dim(DepartmentKey)
);

Use SuperMarket_DW
go

CREATE TABLE Sales_Fact(
    SaleKey INT NOT NULL IDENTITY,
    CalendarKey INT,
	InvoiceID INT,
    BranchKey INT,
    CustomerKey INT,
    ProductKey INT,
    PaymentMethodKey INT,
    Quantity INT,
    UnitPrice FLOAT,
    
  TotalAmount FLOAT,
    Rating INT,
	PaymentDate VARCHAR(255),
    PaymentTime VARCHAR(255),
	 PRIMARY KEY (SaleKey),
    FOREIGN KEY (CalendarKey) REFERENCES Calendar_Dim(CalendarKey),
    FOREIGN KEY (BranchKey) REFERENCES BranchesDim(BranchKey),
    FOREIGN KEY (CustomerKey) REFERENCES CustomersDime(CustomerKey),
    FOREIGN KEY (ProductKey) REFERENCES ProductsDim(ProductKey),
    FOREIGN KEY (PaymentMethodKey) REFERENCES PaymentMethodsDimension(PaymentMethodKey)
);
Use SuperMarket_DW
go
Select * from CustomersDime