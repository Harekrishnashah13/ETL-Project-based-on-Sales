SELECT Branches.BranchID, Customers.CustomerID, Products.ProductID, PaymentMethods.PaymentMethodID, PaymentMethods.InvoiceID, PaymentMethods.PaymentDate, PaymentMethods.PaymentTime, PaymentMethods.UnitPrice, 
                  PaymentMethods.TotalAmount, Products.Quantity, Customers.Rating
FROM     Branches INNER JOIN
                  Customers ON Branches.BranchID = Customers.BranchID INNER JOIN
                  PaymentMethods ON Branches.BranchID = PaymentMethods.BranchID INNER JOIN
                  Products ON Branches.BranchID = Products.BranchID